export const Colors = {
  primary: '#38a69d',      
  accent: '#FFC107',       
  black: '#000000',
  white: '#FFFFFF',
  grayLight: '#f4f3f2',    
  grayMedium: '#ccc',      
  grayDark: '#555',        
  red: '#e53935',          
  green: '#4CAF50',        
};